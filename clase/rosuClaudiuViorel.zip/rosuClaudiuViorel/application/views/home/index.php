<div class="jumbotron mt-3 ">
	<div class="container">
	  <h1 class="display-5 font-weight-bold">Bienvenido <br />al examen de Rosu Viorel!</h1>
	  <h3>Escoge una opción</h3>
	  <table class="table">
	  	<tr>
	  		<td>Equipo</td>
	  		<td><a href="<?=base_url().'equipo/index';?>">Listar</a> / <a href="<?=base_url().'equipo/create';?>">Crear</a></td>
	  	</tr>
	  	<tr>
	  		<td>Jornada</td>
	  		<td><a href="<?=base_url().'jornada/index';?>">Listar</a> / <a href="<?=base_url().'jornada/create';?>">Crear</a>
	  	</tr>
	  	<tr>
	  		<td>Resultados</td>
	  		<td><a href="<?=base_url().'resultado/create';?>">Crear</a>
	  	</tr>
	  </table>
	</div>
</div>
