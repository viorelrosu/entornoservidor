<header class="py-3">
<div class="row">
  <div class="col text-center pt-1">
    Aplicación Code Igniter + RedBeanPHP + Bootstrap
  </div>
</div>
</header>

<!-- <div class="row pt-2">
	<div class="col">
		<h1><?=isset($head['titulo']) ? $head['titulo'] : 'Aplicación'; ?></h1>
	</div>
</div> -->