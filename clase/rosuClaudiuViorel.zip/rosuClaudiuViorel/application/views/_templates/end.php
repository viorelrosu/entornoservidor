	</div>
	<!-- end container -->
<script type="text/javascript" src="<?=base_url().'assets/js/app.js';?>"></script>
</body>
</html>