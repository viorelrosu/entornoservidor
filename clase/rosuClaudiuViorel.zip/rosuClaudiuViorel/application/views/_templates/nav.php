<div class="row">
	<div class="col">
		<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
			<a class="navbar-brand" href="<?=base_url()?>">EX</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			    <span class="navbar-toggler-icon"></span>
			</button>
			  <div class="collapse navbar-collapse" id="navbarNav">
			    <ul class="navbar-nav mr-auto">
			      <li class="nav-item">
			        <a class="nav-link" href="<?=base_url().'equipo'?>">Equipos</a>
			      </li>
			      <li class="nav-item">
			        <a class="nav-link" href="<?=base_url().'jornada'?>">Jornadas</a>
			      </li>
			      <li class="nav-item">
				    <a class="nav-link" href="<?=base_url().'resultado/create'?>">Registar Resultado</a>
				  </li>
					 </ul>
			  </div>
		</nav>

	</div>
</div>

<main role="main" class="container py-5" style="min-height: 500px;">
