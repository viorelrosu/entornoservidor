</main>

<!-- Footer -->
<footer class="page-footer font-small text-white bg-secondary mt-3">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">
  	© 2020 Copyright | DAW2 Entorno Servidor | Desarrollado por Viorel Rosu
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->