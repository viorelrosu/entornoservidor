
<div class="jumbotron mt-3 ">
	<div class="container">
		<div class="row">
			 <h1 class="display-3 font-weight-bold">Bienvenido Alberto!</h1>
		</div>
		<div class="row mt-3">
			<h4>Por favor, inicia primero la aplicación</h4>
		</div>
		<div class="row">
			<a class="btn btn-primary mr-2" href="<?=base_url().'home/init';?>">Iniciar Aplicación</a>
		</div>
	</div>
</div>
